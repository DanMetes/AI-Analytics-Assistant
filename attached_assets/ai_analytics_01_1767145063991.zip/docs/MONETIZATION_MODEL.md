# Monetization Model

Pricing is tied to compute envelopes, not UI features.

## Metered
- Profiling
- LLM interpretation
- Ask & Explore
- Code generation

## Always Included
- Metrics
- Anomaly detection
- Deterministic interpretation
