# Roadmap

## Phase 1
- Replit-based execution
- Single-tenant experience
- Guaranteed profiling

## Phase 2
- Containerized workers
- Job queue
- Object storage

## Phase 3
- Collaboration
- Sharing
- Audit exports

Non-goals: real-time dashboards, streaming analytics.
