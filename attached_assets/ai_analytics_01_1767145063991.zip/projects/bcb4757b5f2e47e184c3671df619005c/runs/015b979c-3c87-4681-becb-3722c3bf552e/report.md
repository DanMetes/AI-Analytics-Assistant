# Analyst Agent Report

## Executive Summary
- Critical — avg_units for 2023 is 113.0× the median across periods. (avg_units=310.4)
- Critical — sum_units for 2023 is 106.9× the median across periods. (sum_units=5.044e+05)

## Dataset Overview
- Dataset: d17632ee-d5d3-4106-afca-48f63cb8a3c1
- Time candidates: order_date, year
- EDA report: eda_report.html

## Executed Queries
- SELECT COUNT(*) AS n FROM data;
- SELECT "year" AS g0, COUNT(*) AS n, SUM("sales") AS sum_sales, SUM("profit") AS sum_profit, SUM("units") AS sum_units, SUM("discount") AS sum_discount, AVG("sales") AS avg_sales, AVG("profit") AS avg_profit, AVG("units") AS avg_units, AVG("returned") AS rate_returned, CASE WHEN SUM("sales") = 0 THEN NULL ELSE (SUM("profit") * 1.0 / SUM("sales")) END AS profit_margin FROM data GROUP BY "year" ORDER BY "year" LIMIT 250;
- SELECT "region" AS g0, COUNT(*) AS n, SUM("profit") AS sum_profit, SUM("sales") AS sum_sales, CASE WHEN SUM("sales") = 0 THEN NULL ELSE (SUM("profit") * 1.0 / SUM("sales")) END AS profit_margin FROM data GROUP BY "region" ORDER BY SUM("profit") ASC LIMIT 20;

## Execution Warnings
- Failed groupby 'time_x_category': misuse of aggregate: SUM()
- Failed groupby 'time_x_region': misuse of aggregate: SUM()

## Planned Analyses
- [concentration_order_date_units] concentration, metric=units, entity=order_date
- [distribution_1_units] distribution, metric=units
- [distribution_2_sales] distribution, metric=sales
- [distribution_3_unit_price] distribution, metric=unit_price
- [quality_checks] quality, metric=__dataset__
- [segmentation_1_sub_category_units] segmentation, metric=units, by=sub_category
- [segmentation_2_category_units] segmentation, metric=units, by=category
- [segmentation_3_region_units] segmentation, metric=units, by=region
- [trend_1_units] trend, metric=units, time_axis=order_date
- [trend_2_sales] trend, metric=sales, time_axis=order_date
- [trend_3_unit_price] trend, metric=unit_price, time_axis=order_date

## Key Metrics
- anomaly_negative_profit/group_by: group
- anomaly_negative_profit_summary/group=Atlantic:n: 827
- anomaly_negative_profit_summary/group=Atlantic:profit_margin: 0.13968590873404033
- anomaly_negative_profit_summary/group=Atlantic:sum_profit: 84892.08
- anomaly_negative_profit_summary/group=Atlantic:sum_sales: 607735.46
- anomaly_negative_profit_summary/group=North:n: 856
- anomaly_negative_profit_summary/group=North:profit_margin: 0.15758564986047444
- anomaly_negative_profit_summary/group=North:sum_profit: 85901.2
- anomaly_negative_profit_summary/group=North:sum_sales: 545108.01
- anomaly_negative_profit_summary/group=Ontario:n: 812
- anomaly_negative_profit_summary/group=Ontario:profit_margin: 0.16403969863135154
- anomaly_negative_profit_summary/group=Ontario:sum_profit: 104831.51
- anomaly_negative_profit_summary/group=Ontario:sum_sales: 639061.83
- anomaly_negative_profit_summary/group=Prairies:n: 848
- anomaly_negative_profit_summary/group=Prairies:profit_margin: 0.14829632396537515
- anomaly_negative_profit_summary/group=Prairies:sum_profit: 84126.51
- anomaly_negative_profit_summary/group=Prairies:sum_sales: 567286.55
- anomaly_negative_profit_summary/group=Quebec:n: 793
- anomaly_negative_profit_summary/group=Quebec:profit_margin: 0.15708543594019714
- anomaly_negative_profit_summary/group=Quebec:sum_profit: 90964.53
- anomaly_negative_profit_summary/group=Quebec:sum_sales: 579076.79
- anomaly_negative_profit_summary/group=West:n: 864
- anomaly_negative_profit_summary/group=West:profit_margin: 0.15608663707175957
- anomaly_negative_profit_summary/group=West:sum_profit: 90027.56
- anomaly_negative_profit_summary/group=West:sum_sales: 576779.42

## Anomalies
- Critical — avg_units for 2023 is 113.0× the median across periods. (avg_units=310.4)
- Critical — sum_units for 2023 is 106.9× the median across periods. (sum_units=5.044e+05)

## Limitations & Caveats
- Missing data: discount missing_fraction=0.018.
- Missing data: profit missing_fraction=0.009.

## Artifacts
- eda_report.html
- data_profile.json
- analysis_plan.json
- metrics.csv
- anomalies_normalized.json

### Plots
- plots/concentration_order_date_units_units_top10.png
- plots/distribution_1_units_units_hist.png
- plots/distribution_2_sales_sales_hist.png
- plots/distribution_3_unit_price_unit_price_hist.png
- plots/quality_checks_missingness.png
- plots/segmentation_1_sub_category_units_units_by_sub_category.png
- plots/segmentation_2_category_units_units_by_category.png
- plots/segmentation_3_region_units_units_by_region.png
- plots/trend_1_units_units_trend.png
- plots/trend_2_sales_sales_trend.png
- plots/trend_3_unit_price_unit_price_trend.png
