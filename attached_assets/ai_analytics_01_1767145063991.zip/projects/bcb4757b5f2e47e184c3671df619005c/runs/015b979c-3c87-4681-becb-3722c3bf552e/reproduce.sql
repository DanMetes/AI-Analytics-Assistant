SELECT COUNT(*) AS n FROM data;

SELECT "year" AS g0, COUNT(*) AS n, SUM("sales") AS sum_sales, SUM("profit") AS sum_profit, SUM("units") AS sum_units, SUM("discount") AS sum_discount, AVG("sales") AS avg_sales, AVG("profit") AS avg_profit, AVG("units") AS avg_units, AVG("returned") AS rate_returned, CASE WHEN SUM("sales") = 0 THEN NULL ELSE (SUM("profit") * 1.0 / SUM("sales")) END AS profit_margin FROM data GROUP BY "year" ORDER BY "year" LIMIT 250;

SELECT "region" AS g0, COUNT(*) AS n, SUM("profit") AS sum_profit, SUM("sales") AS sum_sales, CASE WHEN SUM("sales") = 0 THEN NULL ELSE (SUM("profit") * 1.0 / SUM("sales")) END AS profit_margin FROM data GROUP BY "region" ORDER BY SUM("profit") ASC LIMIT 20;
