"""Artifact helpers.

Batch R2 scope: centralize canonical artifact paths and ensure the
README artifact contract has concrete files/directories present in every
run folder (placeholders permitted when a stage is not yet implemented).
"""

from .writer import ArtifactWriter

__all__ = ["ArtifactWriter"]
