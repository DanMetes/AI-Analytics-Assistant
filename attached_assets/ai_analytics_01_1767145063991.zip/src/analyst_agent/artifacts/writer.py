from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from ..pipeline.context import RunContext


@dataclass(frozen=True)
class ArtifactWriter:
    """Centralized artifact naming/paths for a pipeline run.

    Batch R2 requirements:
    - Provide canonical paths for the README artifact contract
    - Ensure required files/directories exist (placeholders allowed)
    - Do not modify existing computed artifacts
    """

    ctx: RunContext

    # ---- Canonical contract paths ----
    def path_ingest_meta(self) -> Path:
        return self.ctx.run_dir / "ingest_meta.json"

    def path_eda_report(self) -> Path:
        return self.ctx.run_dir / "eda_report.html"

    def path_data_profile(self) -> Path:
        return self.ctx.run_dir / "data_profile.json"

    def path_analysis_plan(self) -> Path:
        return self.ctx.run_dir / "analysis_plan.json"

    def path_metrics_csv(self) -> Path:
        return self.ctx.run_dir / "metrics.csv"

    def path_anomalies_normalized(self) -> Path:
        return self.ctx.run_dir / "anomalies_normalized.json"

    def path_report_md(self) -> Path:
        return self.ctx.run_dir / "report.md"

    def path_analysis_log(self) -> Path:
        return self.ctx.run_dir / "analysis_log.json"

    def plots_dir(self) -> Path:
        return self.ctx.run_dir / "plots"

    # ---- Contract enforcement ----
    def ensure_contract(self) -> None:
        """Ensure the README artifact contract exists on disk.

        If a file is missing because the stage is not yet implemented,
        write a minimal deterministic placeholder with an `_status` marker.
        Existing artifacts are never overwritten.
        """

        self.ctx.run_dir.mkdir(parents=True, exist_ok=True)

        # Directories
        self._ensure_dir(self.plots_dir())

        # Files (placeholders if missing)
        self._ensure_json(self.path_ingest_meta(), {"_status": "not_implemented"})
        self._ensure_html(self.path_eda_report(), title="EDA Report", status="not_implemented")
        self._ensure_json(self.path_data_profile(), {"_status": "not_implemented"})
        self._ensure_json(self.path_analysis_plan(), {"steps": []})
        self._ensure_csv_header(self.path_metrics_csv(), header="section,key,value\n")
        self._ensure_json(self.path_anomalies_normalized(), {"_status": "not_implemented", "anomalies": []})
        self._ensure_text(
            self.path_report_md(),
            "# Analyst Agent Report\n\n_Status: not_implemented_\n",
        )
        self._ensure_json(self.path_analysis_log(), {"_status": "not_implemented"})

    # ---- Internal helpers ----
    @staticmethod
    def _ensure_dir(path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _ensure_text(path: Path, content: str) -> None:
        if path.exists():
            return
        path.write_text(content, encoding="utf-8")

    @staticmethod
    def _ensure_csv_header(path: Path, header: str) -> None:
        if path.exists():
            return
        path.write_text(header, encoding="utf-8")

    @staticmethod
    def _ensure_json(path: Path, payload: dict) -> None:
        if path.exists():
            return
        # Stable ordering for deterministic placeholders
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    @staticmethod
    def _ensure_html(path: Path, *, title: str, status: str) -> None:
        if path.exists():
            return
        html = (
            "<!doctype html>\n"
            "<html lang=\"en\">\n"
            "<head>\n"
            "  <meta charset=\"utf-8\">\n"
            f"  <title>{title}</title>\n"
            "</head>\n"
            "<body>\n"
            f"  <h1>{title}</h1>\n"
            f"  <p>Status: {status}</p>\n"
            "</body>\n"
            "</html>\n"
        )
        path.write_text(html, encoding="utf-8")
