"""Execution stage.

Batch E1: execute deterministic analysis primitives described in analysis_plan.json.
"""

from .executor import execute_plan  # noqa: F401
