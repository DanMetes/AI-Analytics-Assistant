"""Execution primitives for plan steps (Batch E1)."""
