from __future__ import annotations

from .registry import get_interpreter

__all__ = ["get_interpreter"]
